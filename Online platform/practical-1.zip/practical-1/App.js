import { Text, View, StyleSheet, Button,Linking } from 'react-native';

import React,{useState} from 'react';
// You can import supported modules from npm


export default function App() {
  const[name,setName]=useState('Lusan')
  const[session,setSession]=useState({number:6,title:'Good'})
  
  const[current,setCurrent]=useState(true)

  const onClickHandle=()=>{
    setName('Program')
    setSession({number:9,title:'Night'})
    setCurrent(false)
  }
  
  return (
    <View style={styles.body}>
      <Text style={styles.paragraph}>
         Hiiii {name}
      </Text>
      <Text style={styles.paragraph}>
        Testing number {session.number} and title {session.title}
      </Text>
      <Text style={styles.paragraph}>
        {current?'Now page':'Next Page'}
      </Text>
      <Button title='Click it' style={styles.box} onPress={onClickHandle}></Button>
    </View>
  );
}

const styles = StyleSheet.create({
  body: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    color:'#aaaaaa',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  box:{
    margin:10,
    padding:100,
  }
});
